/*=================================================================
  AZANI ISP INFORMATION SYSTEM
  Access SQL — Table Creation & Sample Data
  KCSE Computer Studies Paper 3, 2026
  
  HOW TO USE:
  1. Open Access → Create → Query Design → SQL View
  2. Paste each CREATE TABLE block and run (!) one at a time
  3. Then paste INSERT statements to add sample data
=================================================================*/

/* ---- NOTE: Access SQL uses different syntax ---- */
/* Run each block separately in Access Query Design  */

/* ============================================================
   STEP 1: CREATE LOOKUP TABLES FIRST
   ============================================================ */

/* Table: tblBandwidthPackages */
CREATE TABLE tblBandwidthPackages (
    PackageID    AUTOINCREMENT PRIMARY KEY,
    Bandwidth    TEXT(20) NOT NULL,
    MonthlyCost  CURRENCY NOT NULL,
    Description  TEXT(100),
    IsAvailable  YESNO DEFAULT Yes
);

/* Table: tblLANNodeTiers */
CREATE TABLE tblLANNodeTiers (
    TierID       AUTOINCREMENT PRIMARY KEY,
    MinNodes     INTEGER NOT NULL,
    MaxNodes     INTEGER NOT NULL,
    TierCost     CURRENCY NOT NULL,
    Description  TEXT(50)
);

/* ============================================================
   STEP 2: CREATE MAIN TABLES
   ============================================================ */

/* Table: tblInstitutions */
CREATE TABLE tblInstitutions (
    InstitutionID       AUTOINCREMENT PRIMARY KEY,
    InstitutionName     TEXT(150) NOT NULL,
    InstitutionType     TEXT(50),
    County              TEXT(80),
    Town                TEXT(80),
    [Address]           MEMO,
    PhoneNumber         TEXT(20) NOT NULL,
    EmailAddress        TEXT(100),
    DateRegistered      DATETIME DEFAULT Now(),
    [Status]            TEXT(20) DEFAULT 'Active',
    RegistrationFeePaid YESNO DEFAULT No,
    InstallationFeePaid YESNO DEFAULT No,
    NumberOfUsers       INTEGER,
    Notes               MEMO
);

/* Table: tblContactPersons */
CREATE TABLE tblContactPersons (
    ContactID       AUTOINCREMENT PRIMARY KEY,
    InstitutionID   LONG NOT NULL,
    ContactName     TEXT(100) NOT NULL,
    Designation     TEXT(80),
    ContactPhone    TEXT(20) NOT NULL,
    ContactEmail    TEXT(100),
    NationalID      TEXT(15)
);

/* Table: tblSubscriptions */
CREATE TABLE tblSubscriptions (
    SubscriptionID    AUTOINCREMENT PRIMARY KEY,
    InstitutionID     LONG NOT NULL,
    PackageID         LONG NOT NULL,
    StartDate         DATETIME,
    EndDate           DATETIME,
    StatusActive      YESNO DEFAULT Yes,
    IsUpgrade         YESNO DEFAULT No,
    PreviousPackageID LONG,
    PaymentStatus     TEXT(20) DEFAULT 'Pending',
    ConnectionStatus  TEXT(20) DEFAULT 'Connected',
    LastPaymentDate   DATETIME,
    DisconnectionDate DATETIME,
    ReconnectionDate  DATETIME
);

/* Table: tblPayments */
CREATE TABLE tblPayments (
    PaymentID       AUTOINCREMENT PRIMARY KEY,
    InstitutionID   LONG NOT NULL,
    PaymentType     TEXT(30) NOT NULL,
    AmountDue       CURRENCY,
    AmountPaid      CURRENCY,
    PaymentDate     DATETIME DEFAULT Now(),
    PaymentMethod   TEXT(30),
    ReferenceNumber TEXT(50),
    [Month]         TEXT(20),
    [Year]          INTEGER,
    RecordedBy      TEXT(80),
    Notes           MEMO
);

/* Table: tblEquipment */
CREATE TABLE tblEquipment (
    EquipmentID        AUTOINCREMENT PRIMARY KEY,
    InstitutionID      LONG NOT NULL,
    NumberOfPCs        INTEGER DEFAULT 0,
    NumberOfNodes      INTEGER DEFAULT 0,
    PCUnitCost         CURRENCY DEFAULT 40000,
    NodeTierCost       CURRENCY DEFAULT 0,
    TotalEquipmentCost CURRENCY DEFAULT 0,
    PurchaseDate       DATETIME,
    DeliveryDate       DATETIME,
    DeliveryStatus     TEXT(20) DEFAULT 'Pending',
    Notes              MEMO
);

/* Table: tblOverdueFines */
CREATE TABLE tblOverdueFines (
    FineID         AUTOINCREMENT PRIMARY KEY,
    InstitutionID  LONG NOT NULL,
    SubscriptionID LONG NOT NULL,
    MonthlyCharge  CURRENCY,
    FineRate       SINGLE DEFAULT 0.15,
    FineAmount     CURRENCY,
    BillingMonth   TEXT(20),
    FineDate       DATETIME DEFAULT Now(),
    FinePaid       YESNO DEFAULT No,
    FinePaidDate   DATETIME
);

/* Table: tblReconnectionFees */
CREATE TABLE tblReconnectionFees (
    ReconnectionID  AUTOINCREMENT PRIMARY KEY,
    InstitutionID   LONG NOT NULL,
    SubscriptionID  LONG NOT NULL,
    ReconnectionFee CURRENCY DEFAULT 1000,
    ReconnectionDate DATETIME DEFAULT Now(),
    FeePaid         YESNO DEFAULT No,
    ProcessedBy     TEXT(80)
);

/* ============================================================
   STEP 3: INSERT SAMPLE/LOOKUP DATA
   ============================================================ */

/* Bandwidth packages (from project Table 1) */
INSERT INTO tblBandwidthPackages (Bandwidth, MonthlyCost, Description) VALUES ('4 MBPS', 1200, 'Basic package — small institutions');
INSERT INTO tblBandwidthPackages (Bandwidth, MonthlyCost, Description) VALUES ('10 MBPS', 2000, 'Standard package — primary schools');
INSERT INTO tblBandwidthPackages (Bandwidth, MonthlyCost, Description) VALUES ('20 MBPS', 3500, 'Enhanced package — junior/senior schools');
INSERT INTO tblBandwidthPackages (Bandwidth, MonthlyCost, Description) VALUES ('25 MBPS', 4000, 'Premium package — large schools');
INSERT INTO tblBandwidthPackages (Bandwidth, MonthlyCost, Description) VALUES ('50 MBPS', 7000, 'Enterprise package — colleges');

/* LAN node tiers (from project Table 2) */
INSERT INTO tblLANNodeTiers (MinNodes, MaxNodes, TierCost, Description) VALUES (2, 10, 10000, '2 – 10 nodes');
INSERT INTO tblLANNodeTiers (MinNodes, MaxNodes, TierCost, Description) VALUES (11, 20, 20000, '11 – 20 nodes');
INSERT INTO tblLANNodeTiers (MinNodes, MaxNodes, TierCost, Description) VALUES (21, 40, 30000, '21 – 40 nodes');
INSERT INTO tblLANNodeTiers (MinNodes, MaxNodes, TierCost, Description) VALUES (41, 100, 40000, '41 – 100 nodes');

/* Sample institutions */
INSERT INTO tblInstitutions (InstitutionName, InstitutionType, County, Town, PhoneNumber, EmailAddress, DateRegistered, [Status], RegistrationFeePaid, InstallationFeePaid, NumberOfUsers)
VALUES ('Sunrise Primary School', 'Primary', 'Nairobi', 'Westlands', '0712345678', 'sunrise@schools.ke', #01/15/2026#, 'Active', Yes, Yes, 45);

INSERT INTO tblInstitutions (InstitutionName, InstitutionType, County, Town, PhoneNumber, EmailAddress, DateRegistered, [Status], RegistrationFeePaid, InstallationFeePaid, NumberOfUsers)
VALUES ('Greenfield Junior School', 'Junior', 'Mombasa', 'Nyali', '0723456789', 'greenfield@schools.ke', #01/20/2026#, 'Active', Yes, Yes, 120);

INSERT INTO tblInstitutions (InstitutionName, InstitutionType, County, Town, PhoneNumber, EmailAddress, DateRegistered, [Status], RegistrationFeePaid, InstallationFeePaid, NumberOfUsers)
VALUES ('Lakewood Senior School', 'Senior', 'Kisumu', 'Milimani', '0734567890', 'lakewood@schools.ke', #02/01/2026#, 'Active', Yes, No, 300);

INSERT INTO tblInstitutions (InstitutionName, InstitutionType, County, Town, PhoneNumber, EmailAddress, DateRegistered, [Status], RegistrationFeePaid, InstallationFeePaid, NumberOfUsers)
VALUES ('Azimio Technical College', 'College', 'Nakuru', 'CBD', '0745678901', 'azimio@college.ke', #02/10/2026#, 'Active', Yes, Yes, 500);

INSERT INTO tblInstitutions (InstitutionName, InstitutionType, County, Town, PhoneNumber, EmailAddress, DateRegistered, [Status], RegistrationFeePaid, InstallationFeePaid, NumberOfUsers)
VALUES ('Baraka Primary School', 'Primary', 'Eldoret', 'Town', '0756789012', 'baraka@schools.ke', #03/01/2026#, 'Active', Yes, Yes, 60);

/* Sample contact persons */
INSERT INTO tblContactPersons (InstitutionID, ContactName, Designation, ContactPhone, ContactEmail, NationalID)
VALUES (1, 'John Kamau', 'Head Teacher', '0712345000', 'jkamau@sunrise.ke', '12345678');

INSERT INTO tblContactPersons (InstitutionID, ContactName, Designation, ContactPhone, ContactEmail, NationalID)
VALUES (2, 'Mary Achieng', 'Principal', '0723456000', 'machieng@greenfield.ke', '23456789');

INSERT INTO tblContactPersons (InstitutionID, ContactName, Designation, ContactPhone, ContactEmail, NationalID)
VALUES (3, 'Peter Omondi', 'ICT Director', '0734567000', 'pomondi@lakewood.ke', '34567890');

INSERT INTO tblContactPersons (InstitutionID, ContactName, Designation, ContactPhone, ContactEmail, NationalID)
VALUES (4, 'Grace Wanjiku', 'IT Manager', '0745678000', 'gwanjiku@azimio.ke', '45678901');

INSERT INTO tblContactPersons (InstitutionID, ContactName, Designation, ContactPhone, ContactEmail, NationalID)
VALUES (5, 'Samuel Rono', 'Head Teacher', '0756789000', 'srono@baraka.ke', '56789012');

/* Sample subscriptions */
INSERT INTO tblSubscriptions (InstitutionID, PackageID, StartDate, StatusActive, IsUpgrade, PaymentStatus, ConnectionStatus, LastPaymentDate)
VALUES (1, 2, #01/15/2026#, Yes, No, 'Paid', 'Connected', #03/31/2026#);

INSERT INTO tblSubscriptions (InstitutionID, PackageID, StartDate, StatusActive, IsUpgrade, PaymentStatus, ConnectionStatus, LastPaymentDate)
VALUES (2, 3, #01/20/2026#, Yes, Yes, 'Paid', 'Connected', #03/31/2026#);

INSERT INTO tblSubscriptions (InstitutionID, PackageID, StartDate, StatusActive, IsUpgrade, PaymentStatus, ConnectionStatus)
VALUES (3, 3, #02/01/2026#, Yes, No, 'Overdue', 'Connected');

INSERT INTO tblSubscriptions (InstitutionID, PackageID, StartDate, StatusActive, IsUpgrade, PaymentStatus, ConnectionStatus, DisconnectionDate)
VALUES (4, 5, #02/10/2026#, Yes, No, 'Overdue', 'Disconnected', #04/10/2026#);

INSERT INTO tblSubscriptions (InstitutionID, PackageID, StartDate, StatusActive, IsUpgrade, PaymentStatus, ConnectionStatus, LastPaymentDate)
VALUES (5, 1, #03/01/2026#, Yes, No, 'Paid', 'Connected', #03/31/2026#);

/* Sample equipment records */
INSERT INTO tblEquipment (InstitutionID, NumberOfPCs, NumberOfNodes, PCUnitCost, NodeTierCost, TotalEquipmentCost, PurchaseDate, DeliveryStatus)
VALUES (3, 5, 8, 40000, 10000, 210000, #02/01/2026#, 'Delivered');

INSERT INTO tblEquipment (InstitutionID, NumberOfPCs, NumberOfNodes, PCUnitCost, NodeTierCost, TotalEquipmentCost, PurchaseDate, DeliveryStatus)
VALUES (1, 0, 5, 40000, 10000, 10000, #01/15/2026#, 'Delivered');

/* ============================================================
   STEP 4: USEFUL ACCESS QUERIES
   (Save each as a named query in Access)
   ============================================================ */

/* qryRegisteredInstitutions */
SELECT i.InstitutionID, i.InstitutionName, i.InstitutionType, i.County, i.Town,
       i.PhoneNumber, i.EmailAddress, i.DateRegistered, i.[Status],
       c.ContactName, c.ContactPhone, c.ContactEmail
FROM tblInstitutions AS i
LEFT JOIN tblContactPersons AS c ON i.InstitutionID = c.InstitutionID
ORDER BY i.DateRegistered DESC;

/* qryDefaulters */
SELECT i.InstitutionID, i.InstitutionName, i.PhoneNumber, b.Bandwidth, b.MonthlyCost,
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost) AS MonthlyCharge,
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)*0.15 AS OverdueFine,
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost) +
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)*0.15 AS TotalDue,
       s.LastPaymentDate, s.PaymentStatus
FROM tblInstitutions AS i
INNER JOIN tblSubscriptions AS s ON i.InstitutionID = s.InstitutionID
INNER JOIN tblBandwidthPackages AS b ON s.PackageID = b.PackageID
WHERE s.PaymentStatus = 'Overdue' AND s.StatusActive = True
ORDER BY i.InstitutionName;

/* qryDisconnections */
SELECT i.InstitutionID, i.InstitutionName, i.PhoneNumber, s.ConnectionStatus,
       s.DisconnectionDate,
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost) AS MonthlyCharge,
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)*0.15 AS OverdueFine,
       1000 AS ReconnectionFee,
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost) +
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)*0.15 + 1000 AS TotalToReconnect
FROM tblInstitutions AS i
INNER JOIN tblSubscriptions AS s ON i.InstitutionID = s.InstitutionID
INNER JOIN tblBandwidthPackages AS b ON s.PackageID = b.PackageID
WHERE s.ConnectionStatus = 'Disconnected'
ORDER BY s.DisconnectionDate;

/* qryInfrastructureRequirements */
SELECT i.InstitutionName, i.InstitutionType,
       e.NumberOfPCs, e.NumberOfNodes,
       e.NumberOfPCs * 40000 AS PCCost,
       Switch(
           e.NumberOfNodes Between 2 And 10, 10000,
           e.NumberOfNodes Between 11 And 20, 20000,
           e.NumberOfNodes Between 21 And 40, 30000,
           e.NumberOfNodes Between 41 And 100, 40000
       ) AS LANCost,
       (e.NumberOfPCs * 40000) + Switch(
           e.NumberOfNodes Between 2 And 10, 10000,
           e.NumberOfNodes Between 11 And 20, 20000,
           e.NumberOfNodes Between 21 And 40, 30000,
           e.NumberOfNodes Between 41 And 100, 40000
       ) AS TotalEquipmentCost
FROM tblInstitutions AS i
INNER JOIN tblEquipment AS e ON i.InstitutionID = e.InstitutionID
ORDER BY i.InstitutionName;

/* qryTotalInstallationCost */
SELECT i.InstitutionName, 8500 AS RegistrationFee, 10000 AS InstallationFee,
       e.NumberOfPCs * 40000 AS PCCost,
       Switch(
           e.NumberOfNodes Between 2 And 10, 10000,
           e.NumberOfNodes Between 11 And 20, 20000,
           e.NumberOfNodes Between 21 And 40, 30000,
           e.NumberOfNodes Between 41 And 100, 40000,
           True, 0
       ) AS LANCost,
       8500 + 10000 + e.NumberOfPCs * 40000 +
       Switch(
           e.NumberOfNodes Between 2 And 10, 10000,
           e.NumberOfNodes Between 11 And 20, 20000,
           e.NumberOfNodes Between 21 And 40, 30000,
           e.NumberOfNodes Between 41 And 100, 40000,
           True, 0
       ) AS TotalInstallationCost
FROM tblInstitutions AS i
INNER JOIN tblEquipment AS e ON i.InstitutionID = e.InstitutionID
ORDER BY TotalInstallationCost DESC;

/* qryMonthlyByCategory */
SELECT i.InstitutionType,
       Count(i.InstitutionID) AS NumberOfInstitutions,
       Sum(IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)) AS TotalMonthlyCharges,
       Sum(IIf(s.PaymentStatus='Overdue', IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)*0.15, 0)) AS TotalOverdueFines,
       Sum(IIf(s.ConnectionStatus='Reconnected', 1000, 0)) AS TotalReconnectionFees,
       Sum(IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)) +
       Sum(IIf(s.PaymentStatus='Overdue', IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)*0.15, 0)) +
       Sum(IIf(s.ConnectionStatus='Reconnected', 1000, 0)) AS GrandTotal
FROM tblInstitutions AS i
INNER JOIN tblSubscriptions AS s ON i.InstitutionID = s.InstitutionID
INNER JOIN tblBandwidthPackages AS b ON s.PackageID = b.PackageID
WHERE s.StatusActive = True
GROUP BY i.InstitutionType
ORDER BY GrandTotal DESC;

/* qryAggregatePerInstitution */
SELECT i.InstitutionID, i.InstitutionName, i.InstitutionType, b.Bandwidth,
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost) AS MonthlyCharge,
       IIf(s.PaymentStatus='Overdue', IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)*0.15, 0) AS OverdueFine,
       IIf(s.ConnectionStatus='Reconnected', 1000, 0) AS ReconnectionFee,
       IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost) +
       IIf(s.PaymentStatus='Overdue', IIf(s.IsUpgrade=True, b.MonthlyCost*0.9, b.MonthlyCost)*0.15, 0) +
       IIf(s.ConnectionStatus='Reconnected', 1000, 0) AS AggregateAmount,
       s.PaymentStatus, s.ConnectionStatus
FROM tblInstitutions AS i
INNER JOIN tblSubscriptions AS s ON i.InstitutionID = s.InstitutionID
INNER JOIN tblBandwidthPackages AS b ON s.PackageID = b.PackageID
WHERE s.StatusActive = True
ORDER BY AggregateAmount DESC, i.InstitutionName;
