'================================================================
' AZANI ISP INFORMATION SYSTEM
' VBA Code Module
' KCSE Computer Studies Paper 3, 2026
'
' HOW TO USE:
'   1. Open Access database
'   2. Press Alt + F11 to open the VBA Editor
'   3. Insert > Module (for basFormStyling and basBusinessLogic)
'   4. For form-specific code, double-click the form in the
'      Project pane and paste the relevant Sub procedures
'================================================================

Option Compare Database
Option Explicit

'================================================================
' MODULE: basFormStyling
' Purpose: Centralised colour and style constants + helpers
'================================================================

' ── Colour constants (RGB values as Long) ──────────────────────
Public Const CLR_PRIMARY   As Long = 2039585    ' #1F4E79 dark blue
Public Const CLR_ACCENT    As Long = 2263505    ' #2E86C1 accent blue
Public Const CLR_SUCCESS   As Long = 1970218    ' #1E8449 green
Public Const CLR_DANGER    As Long = 2763832    ' #C0392B red
Public Const CLR_WARNING   As Long = 12490823   ' #BE7D07 amber
Public Const CLR_LIGHT     As Long = 15987698   ' #F2F3F4 light grey
Public Const CLR_WHITE     As Long = 16777215   ' #FFFFFF white
Public Const CLR_DARK      As Long = 1513498    ' #17202A near-black
Public Const CLR_HEADER_TXT As Long = 12496111  ' #BEE4EF pale blue text

' ── Apply primary button style ─────────────────────────────────
Public Sub StylePrimaryBtn(btn As CommandButton, Optional bgColor As Long = CLR_PRIMARY)
    With btn
        .BackColor = bgColor
        .ForeColor = CLR_WHITE
        .SpecialEffect = 0    ' Flat
        .BorderStyle = 0
        .FontName = "Arial"
        .FontSize = 10
        .FontBold = True
    End With
End Sub

' ── Apply secondary button style ───────────────────────────────
Public Sub StyleSecondaryBtn(btn As CommandButton)
    With btn
        .BackColor = CLR_LIGHT
        .ForeColor = CLR_DARK
        .SpecialEffect = 0
        .BorderStyle = 1
        .FontName = "Arial"
        .FontSize = 10
        .FontBold = False
    End With
End Sub

' ── Apply text box style ───────────────────────────────────────
Public Sub StyleTxt(txt As TextBox)
    With txt
        .BackColor = CLR_WHITE
        .BorderColor = RGB(189, 195, 199)
        .BorderStyle = 1
        .SpecialEffect = 0
        .FontName = "Arial"
        .FontSize = 10
        .ForeColor = CLR_DARK
    End With
End Sub

' ── Apply combo box style ──────────────────────────────────────
Public Sub StyleCombo(cbo As ComboBox)
    With cbo
        .BackColor = CLR_WHITE
        .BorderColor = RGB(189, 195, 199)
        .SpecialEffect = 0
        .FontName = "Arial"
        .FontSize = 10
        .ForeColor = CLR_DARK
    End With
End Sub

' ── Apply label style ──────────────────────────────────────────
Public Sub StyleLbl(lbl As Label, Optional isBold As Boolean = False)
    With lbl
        .ForeColor = CLR_DARK
        .FontName = "Arial"
        .FontSize = 10
        .FontBold = isBold
        .BackStyle = 0     ' Transparent
    End With
End Sub

'================================================================
' MODULE: basBusinessLogic
' Purpose: All business rule calculations
'================================================================

' ── Node tier cost lookup ──────────────────────────────────────
Public Function GetNodeTierCost(numNodes As Integer) As Currency
    Select Case numNodes
        Case 0 To 1:         GetNodeTierCost = 0
        Case 2 To 10:        GetNodeTierCost = 10000
        Case 11 To 20:       GetNodeTierCost = 20000
        Case 21 To 40:       GetNodeTierCost = 30000
        Case 41 To 100:      GetNodeTierCost = 40000
        Case Else:           GetNodeTierCost = 40000
    End Select
End Function

' ── Total equipment cost ───────────────────────────────────────
Public Function CalcEquipmentCost(numPCs As Integer, numNodes As Integer) As Currency
    CalcEquipmentCost = (numPCs * 40000) + GetNodeTierCost(numNodes)
End Function

' ── Total installation cost (reg + install + equipment) ────────
Public Function CalcTotalInstallCost(instID As Long) As Currency
    Dim regFee As Currency: regFee = 8500
    Dim installFee As Currency: installFee = 10000
    Dim eqCost As Currency: eqCost = 0
    
    Dim rs As DAO.Recordset
    On Error GoTo ErrHandler
    Set rs = CurrentDb.OpenRecordset( _
        "SELECT NumberOfPCs, NumberOfNodes FROM tblEquipment WHERE InstitutionID=" & instID)
    If Not rs.EOF Then
        eqCost = CalcEquipmentCost(rs!NumberOfPCs, rs!NumberOfNodes)
    End If
    rs.Close: Set rs = Nothing
    
    CalcTotalInstallCost = regFee + installFee + eqCost
    Exit Function
ErrHandler:
    CalcTotalInstallCost = regFee + installFee
End Function

' ── Monthly charge (with upgrade discount) ─────────────────────
Public Function CalcMonthlyCharge(instID As Long) As Currency
    Dim rs As DAO.Recordset
    Dim base As Currency
    Dim isUpg As Boolean
    
    On Error GoTo ErrHandler
    Set rs = CurrentDb.OpenRecordset( _
        "SELECT s.IsUpgrade, b.MonthlyCost " & _
        "FROM tblSubscriptions s " & _
        "INNER JOIN tblBandwidthPackages b ON s.PackageID = b.PackageID " & _
        "WHERE s.InstitutionID=" & instID & " AND s.StatusActive=True")
    If Not rs.EOF Then
        base = rs!MonthlyCost
        isUpg = rs!IsUpgrade
    End If
    rs.Close: Set rs = Nothing
    
    CalcMonthlyCharge = IIf(isUpg, base * 0.9, base)
    Exit Function
ErrHandler:
    CalcMonthlyCharge = 0
End Function

' ── Overdue fine (15%) ─────────────────────────────────────────
Public Function CalcOverdueFine(monthlyCharge As Currency) As Currency
    CalcOverdueFine = monthlyCharge * 0.15
End Function

' ── Reconnection fee (fixed KSh 1,000) ────────────────────────
Public Function GetReconnectionFee() As Currency
    GetReconnectionFee = 1000
End Function

' ── Total aggregate for one institution ───────────────────────
Public Function CalcAggregateTotal(instID As Long) As Currency
    Dim monthly As Currency
    Dim fine As Currency
    Dim reconnect As Currency
    
    monthly = CalcMonthlyCharge(instID)
    
    ' Check if overdue
    Dim rs As DAO.Recordset
    Set rs = CurrentDb.OpenRecordset( _
        "SELECT PaymentStatus, ConnectionStatus FROM tblSubscriptions " & _
        "WHERE InstitutionID=" & instID & " AND StatusActive=True")
    If Not rs.EOF Then
        If rs!PaymentStatus = "Overdue" Then fine = CalcOverdueFine(monthly)
        If rs!ConnectionStatus = "Reconnected" Then reconnect = GetReconnectionFee()
    End If
    rs.Close: Set rs = Nothing
    
    CalcAggregateTotal = monthly + fine + reconnect
End Function

'================================================================
' FORM: frmMainMenu
'================================================================
Private Sub Form_Load()
    ' Header styling
    Me.FormHeader.BackColor = CLR_PRIMARY
    Me.Detail.BackColor = CLR_LIGHT

    ' Title labels
    Me.lblTitle.ForeColor = CLR_WHITE
    Me.lblTitle.FontSize = 18
    Me.lblTitle.FontBold = True
    Me.lblSubtitle.ForeColor = CLR_HEADER_TXT
    Me.lblSubtitle.FontSize = 10
    Me.lblDate.Caption = "Date: " & Format(Date, "DD MMMM YYYY")
    Me.lblDate.ForeColor = CLR_HEADER_TXT

    ' Navigation buttons
    StylePrimaryBtn Me.btnRegister,  RGB(31, 78, 121)
    StylePrimaryBtn Me.btnPayments,  RGB(30, 132, 73)
    StylePrimaryBtn Me.btnEquipment, RGB(192, 57, 43)
    StylePrimaryBtn Me.btnReports,   RGB(125, 60, 152)
    StylePrimaryBtn Me.btnDefaulters, RGB(211, 84, 0)
    StyleSecondaryBtn Me.btnExit

    DoCmd.Maximize
End Sub

Private Sub btnRegister_Click():  DoCmd.OpenForm "frmInstitutionRegistration": End Sub
Private Sub btnPayments_Click():  DoCmd.OpenForm "frmPayments": End Sub
Private Sub btnEquipment_Click(): DoCmd.OpenForm "frmEquipment": End Sub
Private Sub btnReports_Click():   DoCmd.OpenForm "frmReportLauncher": End Sub
Private Sub btnDefaulters_Click(): DoCmd.OpenReport "rptDefaulters", acViewPreview: End Sub
Private Sub btnExit_Click()
    If MsgBox("Exit the Azani ISP System?", vbYesNo + vbQuestion + vbDefaultButton2, "Exit") = vbYes Then
        Application.Quit acQuitSaveAll
    End If
End Sub

'================================================================
' FORM: frmInstitutionRegistration
'================================================================
Private Sub Form_Load_Registration()
    ' Header
    Me.FormHeader.BackColor = CLR_PRIMARY
    Me.lblFormTitle.ForeColor = CLR_WHITE
    Me.lblFormTitle.FontBold = True
    Me.lblFormTitle.FontSize = 14
    Me.Detail.BackColor = CLR_WHITE

    ' Buttons
    StylePrimaryBtn Me.btnSave
    StylePrimaryBtn Me.btnNew,    CLR_SUCCESS
    StyleSecondaryBtn Me.btnDelete
    StyleSecondaryBtn Me.btnPrint
    StyleSecondaryBtn Me.btnClose

    ' Text boxes
    StyleTxt Me.txtInstitutionName
    StyleTxt Me.txtCounty
    StyleTxt Me.txtTown
    StyleTxt Me.txtPhoneNumber
    StyleTxt Me.txtEmailAddress
    StyleTxt Me.txtNumberOfUsers

    ' Combos
    StyleCombo Me.cboInstitutionType
    StyleCombo Me.cboStatus

    ' Defaults
    Me.txtDateRegistered = Date
    Me.txtRegistrationFee = "KSh 8,500"
    Me.cboStatus = "Active"
End Sub

Private Sub btnSave_Click()
    ' Validation
    If IsNull(Me.txtInstitutionName) Or Trim(Me.txtInstitutionName) = "" Then
        MsgBox "Institution name cannot be blank.", vbExclamation, "Validation Error"
        Me.txtInstitutionName.SetFocus: Exit Sub
    End If
    If IsNull(Me.txtPhoneNumber) Or Trim(Me.txtPhoneNumber) = "" Then
        MsgBox "Phone number is required.", vbExclamation, "Validation Error"
        Me.txtPhoneNumber.SetFocus: Exit Sub
    End If
    DoCmd.RunCommand acCmdSaveRecord
    MsgBox "Institution registered successfully!" & vbCrLf & _
           "Registration Fee: KSh 8,500", vbInformation, "Azani ISP System"
End Sub

Private Sub btnNew_Click():    DoCmd.GoToRecord , , acNewRec: End Sub
Private Sub btnDelete_Click()
    If MsgBox("Delete this institution record? This cannot be undone.", _
              vbYesNo + vbCritical, "Confirm Delete") = vbYes Then
        DoCmd.RunCommand acCmdDeleteRecord
    End If
End Sub
Private Sub btnPrint_Click():  DoCmd.PrintOut: End Sub
Private Sub btnClose_Click():  DoCmd.Close acForm, Me.Name: End Sub

'================================================================
' FORM: frmSubscription
'================================================================
Private Sub Form_Load_Subscription()
    Me.FormHeader.BackColor = CLR_ACCENT
    Me.lblFormTitle.ForeColor = CLR_WHITE
    Me.Detail.BackColor = CLR_WHITE

    StylePrimaryBtn Me.btnActivate,   CLR_SUCCESS
    StylePrimaryBtn Me.btnDisconnect, CLR_DANGER
    StylePrimaryBtn Me.btnReconnect,  CLR_WARNING
    StyleSecondaryBtn Me.btnClose

    StyleCombo Me.cboInstitution
    StyleCombo Me.cboPackage

    Me.txtStartDate = Date
    Me.chkIsUpgrade = False
    UpdateChargeDisplay
End Sub

Private Sub cboPackage_AfterUpdate()
    UpdateChargeDisplay
End Sub

Private Sub chkIsUpgrade_AfterUpdate()
    UpdateChargeDisplay
End Sub

Private Sub UpdateChargeDisplay()
    Dim baseCost As Currency
    If Not IsNull(Me.cboPackage) Then
        baseCost = DLookup("MonthlyCost", "tblBandwidthPackages", "PackageID=" & Me.cboPackage)
        If Me.chkIsUpgrade = True Then
            Me.txtMonthlyCharge = baseCost * 0.9
            Me.txtDiscount = baseCost * 0.1
            Me.lblDiscountNote.Caption = "10% upgrade discount applied — Save KSh " & Format(baseCost * 0.1, "#,##0")
            Me.lblDiscountNote.ForeColor = CLR_SUCCESS
        Else
            Me.txtMonthlyCharge = baseCost
            Me.txtDiscount = 0
            Me.lblDiscountNote.Caption = ""
        End If
    End If
End Sub

Private Sub btnActivate_Click()
    If IsNull(Me.cboInstitution) Then
        MsgBox "Please select an institution.", vbExclamation, "Azani ISP": Exit Sub
    End If
    If IsNull(Me.cboPackage) Then
        MsgBox "Please select a bandwidth package.", vbExclamation, "Azani ISP": Exit Sub
    End If
    Me.cboStatus = "Connected"
    DoCmd.RunCommand acCmdSaveRecord
    MsgBox "Subscription activated successfully!", vbInformation, "Azani ISP System"
End Sub

Private Sub btnDisconnect_Click()
    If MsgBox("Disconnect internet for this institution?", vbYesNo + vbExclamation, "Disconnect") = vbYes Then
        Me.cboConnectionStatus = "Disconnected"
        Me.txtDisconnectionDate = Date
        DoCmd.RunCommand acCmdSaveRecord
        MsgBox "Institution has been disconnected.", vbInformation, "Azani ISP System"
    End If
End Sub

Private Sub btnReconnect_Click()
    Dim msg As String
    msg = "Reconnecting will charge KSh 1,000 reconnection fee." & vbCrLf & _
          "The institution must also clear outstanding balance." & vbCrLf & vbCrLf & _
          "Proceed with reconnection?"
    If MsgBox(msg, vbYesNo + vbQuestion, "Reconnection") = vbYes Then
        Me.cboConnectionStatus = "Reconnected"
        Me.txtReconnectionDate = Date
        DoCmd.RunCommand acCmdSaveRecord
        ' Record reconnection fee
        CurrentDb.Execute "INSERT INTO tblReconnectionFees " & _
            "(InstitutionID, SubscriptionID, ReconnectionFee, ReconnectionDate, FeePaid) " & _
            "VALUES (" & Me.cboInstitution & ", " & Me.SubscriptionID & ", 1000, #" & Date & "#, False)"
        MsgBox "Reconnection recorded. KSh 1,000 fee has been charged.", vbInformation, "Azani ISP"
    End If
End Sub

'================================================================
' FORM: frmPayments
'================================================================
Private Sub Form_Load_Payments()
    Me.FormHeader.BackColor = CLR_SUCCESS
    Me.lblFormTitle.ForeColor = CLR_WHITE
    Me.Detail.BackColor = CLR_WHITE

    StylePrimaryBtn Me.btnRecord, CLR_SUCCESS
    StyleSecondaryBtn Me.btnPrintReceipt
    StyleSecondaryBtn Me.btnClose

    StyleCombo Me.cboInstitution
    StyleCombo Me.cboPaymentType
    StyleCombo Me.cboPaymentMethod
    StyleTxt Me.txtAmountDue
    StyleTxt Me.txtAmountPaid
    StyleTxt Me.txtReferenceNumber

    Me.txtPaymentDate = Date
End Sub

Private Sub cboInstitution_AfterUpdate()
    ' Auto-populate amount due based on payment type
    If Me.cboPaymentType = "Monthly" Then
        Me.txtAmountDue = CalcMonthlyCharge(Me.cboInstitution)
    ElseIf Me.cboPaymentType = "Registration" Then
        Me.txtAmountDue = 8500
    ElseIf Me.cboPaymentType = "Installation" Then
        Me.txtAmountDue = 10000
    ElseIf Me.cboPaymentType = "Fine" Then
        Me.txtAmountDue = CalcOverdueFine(CalcMonthlyCharge(Me.cboInstitution))
    ElseIf Me.cboPaymentType = "Reconnection" Then
        Me.txtAmountDue = 1000
    End If
End Sub

Private Sub cboPaymentType_AfterUpdate()
    Call cboInstitution_AfterUpdate   ' Recalculate
End Sub

Private Sub txtAmountPaid_AfterUpdate()
    If Not IsNull(Me.txtAmountDue) And Not IsNull(Me.txtAmountPaid) Then
        Dim balance As Currency
        balance = Me.txtAmountDue - Me.txtAmountPaid
        Me.txtBalance = balance
        If balance > 0 Then
            Me.txtBalance.ForeColor = CLR_DANGER
        Else
            Me.txtBalance.ForeColor = CLR_SUCCESS
        End If
    End If
End Sub

Private Sub btnRecord_Click()
    If IsNull(Me.cboInstitution) Then
        MsgBox "Please select an institution.", vbExclamation: Exit Sub
    End If
    If IsNull(Me.txtAmountPaid) Or Me.txtAmountPaid <= 0 Then
        MsgBox "Please enter the amount paid.", vbExclamation: Exit Sub
    End If
    
    Dim balance As Currency
    balance = Me.txtAmountDue - Me.txtAmountPaid
    
    DoCmd.RunCommand acCmdSaveRecord
    
    If balance <= 0 Then
        ' Mark subscription as paid
        If Me.cboPaymentType = "Monthly" Then
            CurrentDb.Execute "UPDATE tblSubscriptions SET PaymentStatus='Paid', " & _
                "LastPaymentDate=#" & Date & "# WHERE InstitutionID=" & Me.cboInstitution & " AND StatusActive=True"
        End If
        MsgBox "Payment of KSh " & Format(Me.txtAmountPaid, "#,##0") & " recorded." & vbCrLf & _
               "Status: FULLY PAID", vbInformation, "Azani ISP System"
    Else
        MsgBox "Partial payment recorded." & vbCrLf & _
               "Amount paid: KSh " & Format(Me.txtAmountPaid, "#,##0") & vbCrLf & _
               "Outstanding balance: KSh " & Format(balance, "#,##0"), vbExclamation, "Azani ISP System"
    End If
End Sub

Private Sub btnPrintReceipt_Click(): DoCmd.OpenReport "rptPaymentReceipt", acViewPreview: End Sub
Private Sub btnClose_Click(): DoCmd.Close acForm, Me.Name: End Sub

'================================================================
' FORM: frmEquipment
'================================================================
Private Sub Form_Load_Equipment()
    Me.FormHeader.BackColor = CLR_DANGER
    Me.lblFormTitle.ForeColor = CLR_WHITE
    Me.Detail.BackColor = CLR_WHITE

    StylePrimaryBtn Me.btnSave, CLR_DANGER
    StyleSecondaryBtn Me.btnClose

    StyleCombo Me.cboInstitution
    StyleTxt Me.txtNumberOfPCs
    StyleTxt Me.txtNumberOfNodes
End Sub

Private Sub txtNumberOfPCs_AfterUpdate()
    UpdateEquipmentCost
End Sub

Private Sub txtNumberOfNodes_AfterUpdate()
    UpdateEquipmentCost
End Sub

Private Sub UpdateEquipmentCost()
    Dim pcs As Integer
    Dim nodes As Integer
    pcs = Nz(Me.txtNumberOfPCs, 0)
    nodes = Nz(Me.txtNumberOfNodes, 0)
    
    Me.txtPCCost = pcs * 40000
    Me.txtNodeCost = GetNodeTierCost(nodes)
    Me.txtNodeTierDesc = Switch( _
        nodes = 0, "None", _
        nodes Between 2 And 10, "2–10 nodes: KSh 10,000", _
        nodes Between 11 And 20, "11–20 nodes: KSh 20,000", _
        nodes Between 21 And 40, "21–40 nodes: KSh 30,000", _
        nodes Between 41 And 100, "41–100 nodes: KSh 40,000", _
        True, "Invalid node count")
    Me.txtTotalEquipmentCost = CalcEquipmentCost(pcs, nodes)
    Me.txtGrandInstallCost = 8500 + 10000 + Me.txtTotalEquipmentCost
End Sub

Private Sub btnSave_Click()
    ' Update computed fields before saving
    UpdateEquipmentCost
    DoCmd.RunCommand acCmdSaveRecord
    MsgBox "Equipment record saved." & vbCrLf & _
           "Total cost: KSh " & Format(Me.txtGrandInstallCost, "#,##0"), vbInformation, "Azani ISP"
End Sub

'================================================================
' FORM: frmReportLauncher
'================================================================
Private Sub Form_Load_Reports()
    Me.FormHeader.BackColor = RGB(125, 60, 152)
    Me.lblTitle.ForeColor = CLR_WHITE
    Me.Detail.BackColor = CLR_LIGHT

    StylePrimaryBtn Me.btnRptRegistered,  RGB(31, 78, 121)
    StylePrimaryBtn Me.btnRptDefaulters,  CLR_DANGER
    StylePrimaryBtn Me.btnRptDisconnect,  CLR_WARNING
    StylePrimaryBtn Me.btnRptInfra,       CLR_SUCCESS
    StylePrimaryBtn Me.btnRptInstall,     CLR_ACCENT
    StylePrimaryBtn Me.btnRptMonthly,     RGB(125, 60, 152)
    StylePrimaryBtn Me.btnRptAggregate,   CLR_DARK
    StyleSecondaryBtn Me.btnClose
End Sub

Private Sub btnRptRegistered_Click():  DoCmd.OpenReport "rptRegisteredInstitutions", acViewPreview: End Sub
Private Sub btnRptDefaulters_Click():  DoCmd.OpenReport "rptDefaulters", acViewPreview: End Sub
Private Sub btnRptDisconnect_Click():  DoCmd.OpenReport "rptDisconnections", acViewPreview: End Sub
Private Sub btnRptInfra_Click():       DoCmd.OpenReport "rptInfrastructure", acViewPreview: End Sub
Private Sub btnRptInstall_Click():     DoCmd.OpenReport "rptInstallationCost", acViewPreview: End Sub
Private Sub btnRptMonthly_Click():     DoCmd.OpenReport "rptMonthlyByCategory", acViewPreview: End Sub
Private Sub btnRptAggregate_Click():   DoCmd.OpenReport "rptAggregateCharges", acViewPreview: End Sub
Private Sub btnClose_Click():          DoCmd.Close acForm, Me.Name: End Sub

'================================================================
' AutoExec Macro (create as a Macro, not VBA)
' Actions:
'   1. OpenForm    -> frmMainMenu
'   2. MaximizeWindow
' This runs automatically when the database opens.
'================================================================
